=====
pygov
=====

pygov is a Python library that enables easy access to the US Government's data APIs. Read more about the available APIs `here <http://api.data.gov/docs/>`_.

Currently the only (partially) supported API is for the USDA data (specifically the Nutrient Database). Read more about the `USDA NDB API <http://ndb.nal.usda.gov/ndb/doc/>`_.